﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pingpong
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Adatkezelo adatkezelo = new Adatkezelo();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ListaFrissites();
        }

        private void ListaFrissites()
        {
            dgJatekosok.ItemsSource = adatkezelo.JatekosLekerese();
        }

        private void btnMentes_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(txtPont.Text, out int pont))
            {
                MessageBox.Show("A pontszám csak szám lehet!");
                return;
            }

            Jatekos uj = new Jatekos
            {
                Nev = txtNev.Text,
                Pontszam = pont
            };

            adatkezelo.JatekosHozzaadasa(uj);
            ListaFrissites();
        }

        private void btnTorles_Click(object sender, RoutedEventArgs e)
        {
            if (dgJatekosok.SelectedItem is Jatekos kijelolt)
            {
                adatkezelo.JatekosTorlese(kijelolt.Id);
                ListaFrissites();
            }
        }

        private void btnFrissites_Click(object sender, RoutedEventArgs e)
        {
            ListaFrissites();
        }
    }
}