﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace pingpong
{
    class Adatkezelo
    {
        private string connectionString =
            "server=localhost;database=pingpong_db;user=root;password=;";

        public List<Jatekos> JatekosLekerese()
        {
            List<Jatekos> lista = new List<Jatekos>();

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string sql = "SELECT id, nev, pontszam FROM jatekosok ORDER BY pontszam DESC";

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        lista.Add(new Jatekos
                        {
                            Id = reader.GetInt32("id"),
                            Nev = reader.GetString("nev"),
                            Pontszam = reader.GetInt32("pontszam")
                        });
                    }
                }
            }

            return lista;
        }

        public void JatekosHozzaadasa(Jatekos uj)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string sql =
                    "INSERT INTO jatekosok (nev, pontszam) VALUES (@nev, @pont)";

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@nev", uj.Nev);
                    cmd.Parameters.AddWithValue("@pont", uj.Pontszam);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void JatekosTorlese(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string sql = "DELETE FROM jatekosok WHERE id = @id";

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
    



